public class reverse {

    public static void main(String[] args) {
    String str="PWSKILLS";
    StringBuilder rev=new StringBuilder();
    rev.append(str);
    rev.reverse();
    System.out.println(rev);
    

    }
}