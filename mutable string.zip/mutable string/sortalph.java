import java.util.*;
public class sortalph {

    public static void main(String[] args) {
        String inputString = "asdfghjklpoiuytrewqzxcvbnm";
        char[] charArray = inputString.toCharArray();

        Arrays.sort(charArray);
        String sortedString = new String(charArray);

        System.out.println("Original String: " + inputString);
        System.out.println("Sorted String: " + sortedString);
    }
}
